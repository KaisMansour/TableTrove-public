package com.ll.tabletrove_v3.Activities;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.ll.tabletrove_v3.Dao.HttpJsonService;
import com.ll.tabletrove_v3.R;
import com.ll.tabletrove_v3.Dao.SessionManager;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

public class ReservationActivity extends AppCompatActivity {

    private TextView tvNomResto;
    private Button btnChoixDate, btnChoixHeure, btnReserver, btnAnnuler;
    private EditText etDemandeSpeciale;
    private Spinner spinnerNbPersonnes;

    SessionManager sessionManager;
    HttpJsonService apiHelper;

    private String idResto, nomResto, token;
    private Calendar calendar;
    private SimpleDateFormat formatDate, apiFormatter, formatHeureView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);

        sessionManager = new SessionManager(this);

        apiHelper = new HttpJsonService();

        token = sessionManager.getUserToken();

        tvNomResto = findViewById(R.id.tvNomRestoReservation);
        btnChoixDate = findViewById(R.id.btnChoixDateReservation);
        btnChoixHeure = findViewById(R.id.btnChoixHeureReservation);
        btnReserver = findViewById(R.id.btnSoumettreReservation);
        btnAnnuler = findViewById(R.id.btnAnnulerReservation);
        etDemandeSpeciale = findViewById(R.id.etDemandeSpecialeReservation);
        spinnerNbPersonnes = findViewById(R.id.spinnerNbPersonnes);

        idResto = getIntent().getStringExtra("id_restaurant");
        nomResto = getIntent().getStringExtra("nom_restaurant");

        tvNomResto.setText(nomResto);


        calendar = Calendar.getInstance();
        formatDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        formatHeureView = new SimpleDateFormat("HH:mm", Locale.getDefault());

        updateDateButtonText();
        updateTimeButtonText();

        setupSpinnerNbPersonnes();

        setupButtonListeners();
    }

    private void setupSpinnerNbPersonnes() {
        Integer[] listeNombres = new Integer[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, listeNombres);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerNbPersonnes.setAdapter(adapter);

        // 2 personnes par défaut
        spinnerNbPersonnes.setSelection(1);
    }

    private void setupButtonListeners() {
        btnChoixDate.setOnClickListener(v -> {
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    ReservationActivity.this,
                    (view, annee, mois, jour) -> {
                        calendar.set(Calendar.YEAR, annee);
                        calendar.set(Calendar.MONTH, mois);
                        calendar.set(Calendar.DAY_OF_MONTH, jour);
                        updateDateButtonText();
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );

            // Date actuelle par défaut
            datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);

            datePickerDialog.show();
        });

        btnChoixHeure.setOnClickListener(v -> {
            TimePickerDialog timePickerDialog = new TimePickerDialog(
                    ReservationActivity.this,
                    (view, heure, minute) -> {
                        calendar.set(Calendar.HOUR_OF_DAY, heure);
                        calendar.set(Calendar.MINUTE, minute);
                        updateTimeButtonText();
                    },
                    calendar.get(Calendar.HOUR_OF_DAY),
                    calendar.get(Calendar.MINUTE),
                    true

            );
            timePickerDialog.show();
        });

        btnReserver.setOnClickListener(v -> submitReservation());

        btnAnnuler.setOnClickListener(v -> finish());
    }

    private void updateDateButtonText() {
        btnChoixDate.setText(formatDate.format(calendar.getTime()));
    }

    private void updateTimeButtonText() {
        btnChoixHeure.setText(formatHeureView.format(calendar.getTime()));
    }

    private void submitReservation() {

        apiFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        apiFormatter.setTimeZone(TimeZone.getTimeZone("UTC"));

        String dateHeure = apiFormatter.format(calendar.getTime());

        int nbPersonnes = (Integer) spinnerNbPersonnes.getSelectedItem();
        String demandeSpeciale = etDemandeSpeciale.getText().toString().trim();
        // TODO: ajouter demandes speciales a l'envoi vers la BD

        Calendar now = Calendar.getInstance();
        if (calendar.before(now)) {
            Toast.makeText(this, "Veuillez sélectionner une date et une heure dans le futur",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (token == null || token.isEmpty() || idResto == null || idResto.isEmpty()) {
            Toast.makeText(this, "Informations manquantes pour la réservation", Toast.LENGTH_SHORT).show();
            return;
        }

        apiHelper.creerReservation(
                this,
                token,
                idResto,
                dateHeure,
                nbPersonnes,
                new HttpJsonService.ApiCallback<String>() {
                    @Override
                    public void onSuccess(String message) {
                        Toast.makeText(ReservationActivity.this,
                                "Réservation confirmée: " + message, Toast.LENGTH_LONG).show();
                        finish();
                    }

                    @Override
                    public void onFailure(String eMessage) {
                        Toast.makeText(ReservationActivity.this,
                                "Erreur: " + eMessage, Toast.LENGTH_LONG).show();
                        Log.e("ReservationActivity", eMessage);
                    }
                }
        );
    }
}