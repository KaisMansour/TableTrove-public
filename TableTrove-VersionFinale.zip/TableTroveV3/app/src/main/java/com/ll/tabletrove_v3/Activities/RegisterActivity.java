package com.ll.tabletrove_v3.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.ll.tabletrove_v3.Dao.HttpJsonService;
import com.ll.tabletrove_v3.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class RegisterActivity extends AppCompatActivity {

    EditText etPrenom, etNom, etEmail, etTelephone, etMdp, etDdn, etMdp2;
    TextView tvPrenom, tvNom, tvEmail, tvPhone, tvMdp, tvDdn, tvMdp2;

    Button btnSubmit;
    CircleImageView btnRetour;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialiser les vues
        etPrenom = findViewById(R.id.etPrenom);
        etNom = findViewById(R.id.etNom);
        etEmail = findViewById(R.id.etRegisterEmail);
        etTelephone = findViewById(R.id.etTelephone);
        etMdp = findViewById(R.id.etRegisterMdp);
        etDdn = findViewById(R.id.etDateNaiss);
        etMdp2 = findViewById(R.id.etConfirmMdp);
        // Messages d'erreur
        tvPrenom = findViewById(R.id.tvErreurPrenomReg);
        tvNom = findViewById(R.id.tvErreurNomReg);
        tvDdn = findViewById(R.id.tvErreurDdnReg);
        tvPhone = findViewById(R.id.tvErreurPhoneReg);
        tvEmail = findViewById(R.id.tvErreurEmailReg);
        tvMdp = findViewById(R.id.tvErreurMdpReg);
        tvMdp2 = findViewById(R.id.tvErreurMdp2Reg);
        // Boutons
        btnSubmit = findViewById(R.id.btnSubmit);
        btnRetour = findViewById(R.id.btnRetourReg);


        btnRetour.setOnClickListener(v -> {
            Intent iLogin = new Intent(RegisterActivity.this, LoginActivity.class);
            startActivity(iLogin);
        });

        btnSubmit.setOnClickListener(v -> {
            if (validerEntrees()) {

                // Transformer les valeurs de EditText en String pour passer dans ApiHelper
                String prenom = etPrenom.getText().toString().trim();
                String nom = etNom.getText().toString().trim();
                String courriel = etEmail.getText().toString().trim();
                String ddn = etDdn.getText().toString().trim();
                String mdp = etMdp.getText().toString().trim();
                String telephone = etTelephone.getText().toString().trim();

                HttpJsonService apiHelper = new HttpJsonService();
                apiHelper.registerUser(this, prenom, nom, courriel, telephone, ddn, mdp, new HttpJsonService.ApiCallback<String>() {
                    @Override
                    public void onSuccess(String message) {
                        // Afficher un message de succes
                        Toast.makeText(RegisterActivity.this, message, Toast.LENGTH_SHORT).show();

                        // Rediriger vers l'activite LoginActivity
                        Intent iLoginActivity = new Intent(RegisterActivity.this, LoginActivity.class);
                        iLoginActivity.putExtra("email", courriel); // On envoie le courriel rempli
                        startActivity(iLoginActivity);
                        finish();
                    }

                    @Override
                    public void onFailure(String eMessage) {
                        Toast.makeText(RegisterActivity.this, eMessage, Toast.LENGTH_SHORT).show();
                        Log.e("RegisterActivity", eMessage);
                    }
                });
            }
        });

    }
    private boolean validerEntrees() {
        boolean contientValeur = true;

        // Transformer les valeurs de EditText en String pour effectuer la validation
        String prenom = etPrenom.getText().toString().trim();
        String nom = etNom.getText().toString().trim();
        String courriel = etEmail.getText().toString().trim();
        String ddn = etDdn.getText().toString().trim();
        String mdp = etMdp.getText().toString().trim();
        String telephone = etTelephone.getText().toString().trim();
        String confirmMdp = etMdp2.getText().toString().trim();
        
        if (prenom.isEmpty()) {
            tvPrenom.setText("Prénom requis");
            contientValeur = false;
        }
        
        if (nom.isEmpty()) {
            tvNom.setText("Nom requis");
            contientValeur = false;
        }
        
        if (courriel.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(courriel).matches()) {
            tvEmail.setText("Entrer un courriel valide");
            contientValeur = false;
        }
        
        if (telephone.isEmpty()) {
            tvPhone.setText("Numéro de téléphone requis");
            contientValeur = false;
        }
        
        if (ddn.isEmpty()) {
            tvDdn.setText("Date de naissance requise");
            contientValeur = false;
        }
        
        if (mdp.isEmpty() || mdp.length() < 8) {
            tvMdp.setText("Le mot de passe doit contenir au moins 8 caractères.");
            contientValeur = false;
        }
        
        if (!mdp.equals(confirmMdp) || confirmMdp.isEmpty()) {
            tvMdp2.setText("Les mots de passe ne correspondent pas.");
            contientValeur = false;
        }

        return contientValeur;
    }
}