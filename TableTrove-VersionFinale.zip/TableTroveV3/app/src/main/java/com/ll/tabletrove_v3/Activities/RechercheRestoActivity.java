package com.ll.tabletrove_v3.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import androidx.appcompat.app.AppCompatActivity;

import com.ll.tabletrove_v3.Adaptateurs.RestaurantAdapter;
import com.ll.tabletrove_v3.Dao.HttpJsonService;
import com.ll.tabletrove_v3.Modeles.Restaurant;
import com.ll.tabletrove_v3.R;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class RechercheRestoActivity extends AppCompatActivity {

    private EditText etRechercheResto;
    private Spinner spinnerTypeCuisine;
    private ListView lvRestos;
    private CircleImageView btnRetour;

    HttpJsonService apiHelper;
    private List<Restaurant> restos;
    private ArrayAdapter<Restaurant> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recherche_resto);

        apiHelper = new HttpJsonService();

        etRechercheResto = findViewById(R.id.etRechercheResto);
        spinnerTypeCuisine = findViewById(R.id.spinnerTypeCuisine);
        lvRestos = findViewById(R.id.lvRechercheResto);
        btnRetour = findViewById(R.id.btnRetourRecherche);


        btnRetour.setOnClickListener(v -> finish());

        obtenirRestaurantsDepuisAPI();

        setupCuisineTypeSpinner();

        setupRestoListAdapter();
    }

    private void setupCuisineTypeSpinner() {
        List<String> typesCuisine = new ArrayList<>();
        typesCuisine.add("Toutes les cuisines");
        typesCuisine.add("Française");
        typesCuisine.add("Italienne");
        typesCuisine.add("Japonaise");
        typesCuisine.add("Espagnole");
        typesCuisine.add("Indienne");
        typesCuisine.add("Vietnamienne");
        typesCuisine.add("Chinoise");

        ArrayAdapter<String> cuisineAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, typesCuisine);
        cuisineAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTypeCuisine.setAdapter(cuisineAdapter);

        spinnerTypeCuisine.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                filtrerRestos();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void setupRestoListAdapter() {
        restos = new ArrayList<>();
        adapter = new RestaurantAdapter(this, R.layout.restaurant_item, restos);
        lvRestos.setAdapter(adapter);

        lvRestos.setOnItemClickListener((parent, view, position, id) -> {
            Restaurant selectedRestaurant = adapter.getItem(position);
            if (selectedRestaurant != null) {
                Intent intent = new Intent(RechercheRestoActivity.this, DetailRestoActivity.class);
                intent.putExtra("id_restaurant", selectedRestaurant.getId());
                startActivity(intent);
            }
        });
    }


    private void filtrerRestos() {
        String searchText = etRechercheResto.getText().toString().toLowerCase().trim();
        String selectedCuisine = spinnerTypeCuisine.getSelectedItem().toString();

        List<Restaurant> filteredList = new ArrayList<>();

        for (Restaurant restaurant : restos) {
            boolean matchesCuisine = selectedCuisine.equals("Toutes les cuisines") ||
                    restaurant.getCuisineType().equals(selectedCuisine);

            boolean matchesSearch = restaurant.getName().toLowerCase().contains(searchText) ||
                    restaurant.getCuisineType().toLowerCase().contains(searchText) ||
                    restaurant.getAddress().toLowerCase().contains(searchText);

            if (matchesCuisine && matchesSearch) {
                filteredList.add(restaurant);
            }
        }

        adapter.clear();
        adapter.addAll(filteredList);
        adapter.notifyDataSetChanged();
    }

    private void obtenirRestaurantsDepuisAPI() {
        restos = new ArrayList<>();
        adapter = new RestaurantAdapter(this, R.layout.restaurant_item, restos);
        lvRestos.setAdapter(adapter);

        apiHelper.obtenirTousLesRestaurants(this, new HttpJsonService.ApiCallback<JSONArray>() {
            @Override
            public void onSuccess(JSONArray restaurantsArray) {
                try {
                    for (int i = 0; i < restaurantsArray.length(); i++) {
                        JSONObject restaurantObj = restaurantsArray.getJSONObject(i);

                        Restaurant restaurant = new Restaurant(
                                restaurantObj.getString("id_restaurant"),
                                restaurantObj.getString("nom_restaurant"),
                                restaurantObj.optString("description", "Cuisine variée"),
                                restaurantObj.getString("adresse"),
                                "★★★★☆"
                        );

                        restos.add(restaurant);
                    }

                    adapter.notifyDataSetChanged();

                } catch (JSONException e) {
                    Toast.makeText(RechercheRestoActivity.this,
                            "Erreur de traitement des données: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(String eMessage) {
                Toast.makeText(RechercheRestoActivity.this,
                        "Erreur de récupération des restaurants: " + eMessage,
                        Toast.LENGTH_SHORT).show();
                Log.e("RechercheRestoActivity", eMessage);
            }
        });
    }
}