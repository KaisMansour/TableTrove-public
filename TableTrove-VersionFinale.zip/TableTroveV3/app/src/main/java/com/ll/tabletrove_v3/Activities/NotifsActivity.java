package com.ll.tabletrove_v3.Activities;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.ll.tabletrove_v3.Dao.HttpJsonService;
import com.ll.tabletrove_v3.R;
import com.ll.tabletrove_v3.Dao.SessionManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

public class NotifsActivity extends AppCompatActivity {

    CircleImageView btnFermer;
    Button btnHistoriqueReservation;
    LinearLayout containerReservations;
    SessionManager sessionManager;
    HttpJsonService apiHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifs);

        btnFermer = findViewById(R.id.btnFermerNotif);
        btnHistoriqueReservation = findViewById(R.id.btnHistReservationNotif);
        containerReservations = findViewById(R.id.notifs_container);

        sessionManager = new SessionManager(this);
        apiHelper = new HttpJsonService();

        btnFermer.setOnClickListener(v -> finish());

        // Charger les réservations de l'utilisateur s'il est connecté
        if (sessionManager.estConnecte()) {
            chargerReservations();
        } else {
            afficherMessageConnexionRequise();
        }

        btnHistoriqueReservation.setOnClickListener(v -> {
            if (sessionManager.estConnecte()) {
                chargerReservations();
            }
        });
    }

    private void chargerReservations() {
        String token = sessionManager.getUserToken();

        apiHelper.obtenirReservationsUtilisateur(this, token, new HttpJsonService.ApiCallback<JSONArray>() {
            @Override
            public void onSuccess(JSONArray reservations) {
                if (reservations.length() == 0) {
                    afficherAucuneReservation();
                } else {
                    afficherReservations(reservations);
                }
            }

            @Override
            public void onFailure(String eMessage) {
                Toast.makeText(NotifsActivity.this,
                        "Erreur lors du chargement des réservations: " + eMessage,
                        Toast.LENGTH_SHORT).show();
                Log.e("NotifsActivity", eMessage);
            }
        });
    }

    private void afficherReservations(JSONArray reservations) {
        // Vider le conteneur actuel
        containerReservations.removeAllViews();
        Log.d("RESERVATIONS_DEBUG", "Reservation array: " + reservations.toString());

        try {
            for (int i = 0; i < reservations.length(); i++) {
                JSONObject reservation = reservations.getJSONObject(i);

                Log.d("RESERVATION_ITEM", "Reservation " + i + ": " + reservation.toString());

                View reservationView = LayoutInflater.from(this)
                        .inflate(R.layout.item_reservation, containerReservations, false);

                TextView tvNomResto = reservationView.findViewById(R.id.tvNomRestoItem);
                TextView tvNumTable = reservationView.findViewById(R.id.tvNumTableItem);
                TextView tvDateHeure = reservationView.findViewById(R.id.tvDateHeureItem);
                TextView tvNbPersonnes = reservationView.findViewById(R.id.tvNbPersonnesItem);
                Button btnSupprimer = reservationView.findViewById(R.id.btnDeleteReservation);

                int tableId = 0;
                try {
                    tableId = reservation.getInt("id_table");
                    tvNumTable.setText("Table " + tableId);
                } catch (JSONException e) {
                    Log.e("JSON_ERROR", "tableId indisponible : " + e.getMessage());
                    tvNumTable.setText("Numéro de table non trouvé");
                }

                int idResto = 0;
                try {
                    idResto = reservation.getInt("id_restaurant");
                } catch (JSONException e) {
                    Log.e("JSON_ERROR", "idResto invalide : " + e.getMessage());
                }

                if (idResto > 0) {
                    tvNomResto.setText("Restaurant #" + idResto);

                    getNomResto(idResto, tvNomResto);
                } else {
                    tvNomResto.setText("Nom du restaurant indisponible");
                    // TODO: regler probleme de ID nul dans la BD
                }

                String startTime = "Heure de réservation non trouvée";
                try {
                    startTime = reservation.getString("start_time");
                } catch (JSONException e) {
                    Log.e("JSON_ERROR", "Heure : " + e.getMessage());
                }

                int nbPersonnes = 0;
                try {
                    nbPersonnes = reservation.getInt("nombre_personnes");
                } catch (JSONException e) {
                    Log.e("JSON_ERROR", "Erreur: " + e.getMessage());
                }

                final String reservationId = reservation.getString("id_reservation");

                String dateHeureFormatee = formatDate(startTime);
                String nbPersonnesStr = nbPersonnes + " personne(s)";

                tvDateHeure.setText(dateHeureFormatee);
                tvNbPersonnes.setText(nbPersonnesStr);

                btnSupprimer.setOnClickListener(v -> confirmerSuppressionReservation(reservationId));

                containerReservations.addView(reservationView);
            }
        } catch (JSONException e) {
            Log.e("JSON_ERROR", "Error parsing reservations: " + e.getMessage());
            Toast.makeText(this, "Erreur lors de l'affichage des réservations: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }


    private void confirmerSuppressionReservation(final String reservationId) {
        new AlertDialog.Builder(this)
                .setTitle("Annuler la réservation")
                .setMessage("Êtes-vous sûr de vouloir annuler cette réservation ?")
                .setPositiveButton("Oui", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        supprimerReservation(reservationId);
                    }
                })
                .setNegativeButton("Non", null)
                .show();
    }

    private void supprimerReservation(String reservationId) {
        String token = sessionManager.getUserToken();

        apiHelper.supprimerReservation(this, token, reservationId, new HttpJsonService.ApiCallback<String>() {
            @Override
            public void onSuccess(String result) {
                Toast.makeText(NotifsActivity.this, "Réservation annulée avec succès", Toast.LENGTH_SHORT).show();
                chargerReservations();
            }

            @Override
            public void onFailure(String errorMessage) {
                Toast.makeText(NotifsActivity.this,
                        "Erreur lors de l'annulation : " + errorMessage,
                        Toast.LENGTH_SHORT).show();
                Log.e("NotifsActivity", errorMessage);
            }
        });
    }

    private void getNomResto(int restaurantId, final TextView tvNomResto) {
        apiHelper.obtenirDetailsRestaurant(this, String.valueOf(restaurantId), new HttpJsonService.ApiCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                try {
                    String nomRestaurant = result.getString("nom");
                    tvNomResto.setText(nomRestaurant);
                } catch (JSONException e) {
                    Log.e("JSON_ERROR", e.getMessage());
                }
            }

            @Override
            public void onFailure(String eMessage) {
                Log.e("API_ERROR", eMessage);
            }
        });
    }

    private String formatDate(String dateStr) {
        if (dateStr == null || dateStr.equals("Date inconnue")) {
            return dateStr;
        }

        SimpleDateFormat[] inputFormats = {
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()),
                new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault()),
                new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
        };

        SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy à HH:mm", Locale.getDefault());

        for (SimpleDateFormat format : inputFormats) {
            try {
                Date date = format.parse(dateStr);
                return outputFormat.format(date);
            } catch (ParseException e) {
                Log.e("FORMAT_DATE", String.valueOf(e));
            }
        }
        return dateStr;
    }
    private void afficherAucuneReservation() {
        containerReservations.removeAllViews();

        TextView tvAucuneReservation = new TextView(this);
        tvAucuneReservation.setText("Vous n'avez aucune réservation pour le moment");
        tvAucuneReservation.setPadding(32, 64, 32, 64);
        tvAucuneReservation.setTextSize(18);

        containerReservations.addView(tvAucuneReservation);
    }

    private void afficherMessageConnexionRequise() {
        containerReservations.removeAllViews();

        TextView tvConnexionRequise = new TextView(this);
        tvConnexionRequise.setText("Veuillez vous connecter pour voir vos réservations");
        tvConnexionRequise.setPadding(32, 64, 32, 64);
        tvConnexionRequise.setTextSize(18);

        containerReservations.addView(tvConnexionRequise);
    }
}