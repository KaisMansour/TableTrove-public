package com.ll.tabletrove_v3.Adaptateurs;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ll.tabletrove_v3.Modeles.Restaurant;
import com.ll.tabletrove_v3.R;

import java.util.List;

public class RestaurantAdapter extends ArrayAdapter<Restaurant> {
    private Context context;
    private int resource;

    public RestaurantAdapter(@NonNull Context context, int resource, @NonNull List<Restaurant> restaurants) {
        super(context, resource, restaurants);
        this.context = context;
        this.resource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;

        if (view == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            view = inflater.inflate(resource, parent, false);
        }

        Restaurant restaurant = getItem(position);

        if (restaurant != null) {
            TextView tvNomRestaurant = view.findViewById(R.id.tvNomRestaurant);
            TextView tvCuisineType = view.findViewById(R.id.tvCuisineType);
            TextView tvAdresseRestaurant = view.findViewById(R.id.tvAdresseRestaurant);
            TextView tvRatingRestaurant = view.findViewById(R.id.tvRatingRestaurant);

            tvNomRestaurant.setText(restaurant.getName());
            tvCuisineType.setText(restaurant.getCuisineType());
            tvAdresseRestaurant.setText(restaurant.getAddress());
            tvRatingRestaurant.setText(restaurant.getRating());
        }

        return view;
    }
}
