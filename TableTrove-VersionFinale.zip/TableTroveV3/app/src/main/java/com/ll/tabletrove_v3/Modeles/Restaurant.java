package com.ll.tabletrove_v3.Modeles;

public class Restaurant {
    private final String id;
    private final String name;
    private final String cuisineType;
    private final String address;
    private final String rating;

    public Restaurant(String id, String name, String cuisineType, String address, String rating) {
        this.id = id;
        this.name = name;
        this.cuisineType = cuisineType;
        this.address = address;
        this.rating = rating;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCuisineType() {
        return cuisineType;
    }

    public String getAddress() {
        return address;
    }

    public String getRating() {
        return rating;
    }

    @Override
    public String toString() {
        return name + " (" + cuisineType + ")\n" + address + " " + rating;
    }
}
