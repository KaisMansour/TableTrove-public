package com.ll.tabletrove_v3.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.ll.tabletrove_v3.Dao.HttpJsonService;
import com.ll.tabletrove_v3.R;

import org.json.JSONException;
import org.json.JSONObject;

import de.hdodenhof.circleimageview.CircleImageView;

public class DetailRestoActivity extends AppCompatActivity {

    private TextView tvNomResto, tvAdresseResto, tvPhoneResto, tvDescResto, tvCuisineType;
    private Button btnReserver;
    private String restoId;
    private CircleImageView btnRetour;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_resto);

        // Initialiser les vues
        tvNomResto = findViewById(R.id.tvNomRestoDetail);
        tvAdresseResto = findViewById(R.id.tvAdresseRestoDetail);
        tvPhoneResto = findViewById(R.id.tvPhoneRestoDetail);
        tvDescResto = findViewById(R.id.tvDescriptionRestoDetail);
        tvCuisineType = findViewById(R.id.tvTypeCuisineDetail);
        btnReserver = findViewById(R.id.btnReserverDetail);
        btnRetour = findViewById(R.id.btnRetourRestaurantDetail);

        restoId = getIntent().getStringExtra("id_restaurant");
        if (restoId == null || restoId.isEmpty()) {
            Toast.makeText(this, "Erreur: Identifiant de restaurant manquant", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        btnRetour.setOnClickListener(v -> finish());

        btnReserver.setOnClickListener(v -> {
            Intent intent = new Intent(DetailRestoActivity.this, ReservationActivity.class);
            intent.putExtra("id_restaurant", restoId);
            intent.putExtra("nom_restaurant", tvNomResto.getText().toString());
            startActivity(intent);
        });

        loadRestaurantDetails(restoId);
    }

    private void loadRestaurantDetails(String restaurantId) {
        HttpJsonService apiHelper = new HttpJsonService();
        apiHelper.obtenirDetailsRestaurant(this, restaurantId, new HttpJsonService.ApiCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject resto) {
                try {
                    String nomResto = resto.getString("nom_restaurant");
                    String adresse = resto.getString("adresse");
                    String phone = resto.getString("telephone");
                    String description = resto.optString("description", "Aucune description disponible");
                    String typeCuisine = resto.optString("cuisine_type", "Cuisine variée");

                    // TODO: accents aigus texte (accept language french) ***TOUT TEXTE
                    tvNomResto.setText(nomResto);
                    tvAdresseResto.setText(adresse);
                    // TODO: format de numero de telephone 15141234567 -> +1 (514) 123-4567
                    tvPhoneResto.setText(phone);
                    tvDescResto.setText(description);
                    tvCuisineType.setText("Cuisine: " + typeCuisine);

                } catch (JSONException e) {
                    Toast.makeText(DetailRestoActivity.this,
                            "Erreur de traitement des données: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(String eMessage) {
                Toast.makeText(DetailRestoActivity.this,
                        "Erreur de récupération des détails: " + eMessage,
                        Toast.LENGTH_SHORT).show();
                Log.e("DetailRestoActivity", eMessage);
            }
        });
    }
}