package com.ll.tabletrove_v3.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.ll.tabletrove_v3.Dao.HttpJsonService;
import com.ll.tabletrove_v3.R;
import com.ll.tabletrove_v3.Dao.SessionManager;

import de.hdodenhof.circleimageview.CircleImageView;

public class LoginActivity extends AppCompatActivity {

    private EditText etCourriel, etMdp;
    private Button btnLogin, btnSeInscrire, btnSeDeconnecter;
    private CircleImageView btnRetour;
    private TextView tvErreurEmail, tvErreurMdp;

    private SessionManager sessionManager;

    private HttpJsonService apiHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialiser les vues
        etCourriel = findViewById(R.id.etLoginEmail);
        etMdp = findViewById(R.id.etLoginMdp);
        btnLogin = findViewById(R.id.btnLogin);
        btnSeInscrire = findViewById(R.id.btnSeInscrire);
        btnRetour = findViewById(R.id.btnRetourLogin);
        tvErreurEmail = findViewById(R.id.tvErreurEmailLogin);
        tvErreurMdp = findViewById(R.id.tvErreurMdpLogin);
        btnSeDeconnecter = findViewById(R.id.btnSeDeconnecterLogin);

        sessionManager = new SessionManager(this);

        String email = getIntent().getStringExtra("email");

        if (email == null || email.isEmpty()) {
            email = sessionManager.getUserEmail();
        }

        if (email != null && !email.isEmpty()) {
            etCourriel.setText(email);
        }

        if (sessionManager.estConnecte()) {
            btnSeDeconnecter.setVisibility(View.VISIBLE);
        }

        btnSeInscrire.setOnClickListener(v -> {
            Intent iRegister = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(iRegister);
        });

        btnRetour.setOnClickListener(v -> {
            Intent iMain = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(iMain);
        });

        btnLogin.setOnClickListener(v -> {
            String emailEntree = etCourriel.getText().toString().trim();
            String mdp = etMdp.getText().toString().trim();

            if (emailEntree.isEmpty()) {
                tvErreurEmail.setText("Courriel requis");
            }
            if (mdp.isEmpty()) {
                tvErreurMdp.setText("Mot de passe requis");
            }

            sessionManager = new SessionManager(this);

            apiHelper = new HttpJsonService();

            apiHelper.loginUser(
                    LoginActivity.this,
                    emailEntree,
                    mdp,
                    new HttpJsonService.ApiCallback<>() {
                        @Override
                        public void onSuccess(HttpJsonService.LoginResult result) {
                            Toast.makeText(LoginActivity.this, "Connexion réussie", Toast.LENGTH_LONG).show();

                            // Sauvegarder les donnees dans SharedPreferences avec SessionManager
                            sessionManager.creerSessionUser(
                                    result.getToken(),
                                    result.getUserId(),
                                    emailEntree
                            );

                            Intent iMain = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(iMain);
                            finish();
                        }

                        @Override
                        public void onFailure(String eMessage) {
                            Toast.makeText(LoginActivity.this, eMessage, Toast.LENGTH_SHORT).show();
                            Log.e("LoginActivity", eMessage);
                        }
                    }
            );
        });




    }
}