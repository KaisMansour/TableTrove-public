package com.ll.tabletrove_v3.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.ll.tabletrove_v3.R;
import com.ll.tabletrove_v3.Dao.SessionManager;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {

    Button btnRechercher;
    CircleImageView btnSeConnecter, btnSettings, btnNotifs;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialiser le SessionManager
        sessionManager = new SessionManager(this);


        // Initialiser les vues
        btnNotifs = findViewById(R.id.btnNotifs);
        btnSeConnecter = findViewById(R.id.btnSeConnecter);
        btnSettings = findViewById(R.id.btnSettings);
        btnRechercher = findViewById(R.id.btnRechercher);

        btnSeConnecter.setOnClickListener(v -> {

            if (sessionManager.estConnecte()) {
                Intent iProfile = new Intent(MainActivity.this, ProfileActivity.class);
                startActivity(iProfile);
            } else {
                Intent iSeConnecter = new Intent(v.getContext(), LoginActivity.class);
                startActivity(iSeConnecter);
            }

        });

        btnSettings.setOnClickListener(v -> {
            // TODO: options de changer le theme, ajouter preferences alimentaires, allergies, etc.
        });

        btnNotifs.setOnClickListener(v -> {
            Intent iNotifs = new Intent(MainActivity.this, NotifsActivity.class);
            startActivity(iNotifs);
        });
        btnRechercher.setOnClickListener(v -> {

            if (sessionManager.estConnecte()) {
                Intent iRechercheResto = new Intent(v.getContext(), RechercheRestoActivity.class);
                startActivity(iRechercheResto);
            } else {
                Intent iSeConnecter = new Intent(v.getContext(), LoginActivity.class);
                startActivity(iSeConnecter);
            }
        });

    }
}